﻿using CsvHelper;
using G4SAssesment.Enums;
using G4SAssesment.Interfaces;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;

namespace G4SAssesment.Models
{
    public class LeagueData : ILeagueData
    {
        public List<Team> CalculateResuls(List<Team> teams)
        {

            foreach (var team in teams)
            {
                team.Points = team.MatchResult.Sum(x => x.Points);
                team.GamesWon = team.MatchResult.Count(x => x.Result == (int)ResultEnum.Won);
                team.GamesLost = team.MatchResult.Count(x => x.Result == (int)ResultEnum.Loss);
                team.GamesDrawn = team.MatchResult.Count(x => x.Result == (int)ResultEnum.Draw);
                team.GoalsFor = team.MatchResult.Sum(x => x.GoalsFor);
                team.GoalsAgainst = team.MatchResult.Sum(x => x.GoalsAgainst);
                team.GoalDifference = team.GoalsFor - team.GoalsAgainst;
                team.GamesPlayed = team.GamesWon + team.GamesLost + team.GamesDrawn;
            }

            return teams;

        }

        public List<Team> OrderLeagueData(List<Team> teams)
        {

            teams = teams.OrderByDescending(x => x.Points).ThenByDescending(x => x.GoalDifference).ThenByDescending(x => x.GoalsFor).ToList();

            return teams;
        }

        public List<Team> ProccessLeagueData(string filePath)
        {
            List<Team> teams = new List<Team>();

            using (var reader = new StreamReader(filePath))
            {
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {

                    int count = 0;
                    csv.Read();
                    csv.ReadHeader();

                    while (csv.Read())
                    {
                        teams.Add(new Team() { Name = csv.GetField(0) });

                        for (int c = 1; c < csv.HeaderRecord.Length; c++)
                        {
                            string[] macthResultSplit = csv.GetField(c).Split('-');

                            int goalsFor = int.Parse(macthResultSplit[0].Trim());
                            int goalsAgainst = int.Parse(macthResultSplit[1].Trim());

                            MatchResult matchResult = new MatchResult(goalsFor, goalsAgainst);
                            
                            matchResult.SetMatchResultPoint(matchResult.GoalsFor, matchResult.GoalsAgainst);
                            
                            teams[count].MatchResult.Add(matchResult);
                        }
                        count++;
                    }
                }
            }

            return teams;
        }
        public void ProccessLeagueOutputData(string filePath, List<Team> teams, List<string> headers)
        {

            using (var writer = new StreamWriter(filePath))
            {

                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    foreach (var header in headers)
                    {
                        csv.WriteField<string>(header);
                    }

                    foreach (var team in teams)
                    {
                        csv.NextRecord();
                        csv.WriteRecord(team);
                    }
                }
            }
        }

    }
}


