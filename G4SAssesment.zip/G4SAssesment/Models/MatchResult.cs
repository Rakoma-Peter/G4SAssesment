﻿using G4SAssesment.Enums;

namespace G4SAssesment.Models
{
    public class MatchResult
    {
        public int GoalsFor { get; protected set; }
        public int GoalsAgainst { get; protected set; }
        public int Result {get; private set; }
        public int Points { get; private set; }

        public MatchResult(int goalsFor, int goalsAgainst)
        {

            GoalsFor = goalsFor;
            GoalsAgainst = goalsAgainst; 
           
        }
        public void SetMatchResultPoint(int goalsForTeam,int goalsAgainstTeam)
        {
            if (goalsForTeam > goalsAgainstTeam)
            {
                Points = (int)ResultEnum.Won;
                Result = (int)ResultEnum.Won;      
            }

            if (goalsForTeam == goalsAgainstTeam)
            {
                Points = (int)ResultEnum.Draw;
                Result =(int)ResultEnum.Draw;
            }

            if (goalsForTeam < goalsAgainstTeam)
            {
                Points = (int)ResultEnum.Loss;
                Result = (int)ResultEnum.Loss;
               
            }
        }
    }

   
}


