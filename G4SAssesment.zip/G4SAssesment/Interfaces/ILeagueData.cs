﻿using G4SAssesment.Models;
using System.Collections.Generic;

namespace G4SAssesment.Interfaces
{
    public interface ILeagueData
    {
        List<Team> ProccessLeagueData(string filePath);
        void ProccessLeagueOutputData(string filePath, List<Team> teams, List<string> headers);
        List<Team> CalculateResuls(List<Team> teams);
        List<Team> OrderLeagueData(List<Team> teams);
    }

   
}


