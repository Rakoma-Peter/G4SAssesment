﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G4SAssesment.Enums
{
    public enum ResultEnum
    {
        Loss = 0,
        Draw = 1,
        Won = 3
    }
}
