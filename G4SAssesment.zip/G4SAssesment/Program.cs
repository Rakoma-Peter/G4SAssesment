﻿using G4SAssesment.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace G4SAssesment
{
    class Program
    {
        static void Main(string[] args)
        {
           

            string inputFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Data\input.csv");
            string outputFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Data\output.csv");
         
            List<string> outputFileHearders= new List<string>
            { 
                "Team name",
                "Games Played",
                "Games Won",
                "Games Drawn",
                "Games Lost",
                "Goals For",
                "Goals Against",
                "Goal Difference",
                "Points" 
            };

            List<Team> teams = new List<Team>();

            LeagueData leagueData = new LeagueData();

            teams = leagueData.ProccessLeagueData(inputFilePath);

            teams = leagueData.CalculateResuls(teams);
            
            teams = leagueData.OrderLeagueData(teams);

            leagueData.ProccessLeagueOutputData(outputFilePath, teams, outputFileHearders);

            Console.WriteLine("========= Premier League Rankings");
            Console.WriteLine();

            Console.WriteLine("{0,-10}\t{1,-5}\t{2,-5}\t{3,-10}\t{4,-10}\t{5,-10}\t{6,-15}\t{7,-20}\t{8,-15}", outputFileHearders[0], outputFileHearders[1], outputFileHearders[2], outputFileHearders[3], outputFileHearders[4], outputFileHearders[5], outputFileHearders[6], outputFileHearders[7], outputFileHearders[8]);

            foreach (var data in teams)
            {
                Console.WriteLine("{0,-10}\t{1,-15}\t{2,-15}\t{3,-15}\t{4,-15}\t{5,-15}\t{6,-10}\t{7,-20}\t{8,-20}", data.Name, data.GamesPlayed, data.GamesWon , data.GamesDrawn , data.GamesLost, data.GoalsFor, data.GoalsAgainst, data.GoalDifference, data.Points);
            }
            Console.WriteLine();
            Console.WriteLine("========= End of Premier League Rankings");
            Console.WriteLine();
            Console.WriteLine("========= output.csv can be found in 'bin\\Debug\\Data' or  'bin\\Release\\Data' directory");
            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.WriteLine();

            Console.ReadLine();
        }


    }

   
}


